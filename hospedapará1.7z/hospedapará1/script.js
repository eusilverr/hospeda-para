let search = document.querySelector('#serach-bar');
let searchbox = document.querySelector('.search-box');
let menubar = document.querySelector('#menu-bars');
let mynav = document.querySelector('.navbar');




search.onclick = () =>{
    searchbox.classList.toggle('active');
}

menubar.onclick = () =>{
    menubar.classList.toggle('fa-times')
    mynav.classList.toggle('active')
}
const slides = document.querySelectorAll('.slide');
const navLabels = document.querySelectorAll('.nav');
let currentSlide = 0;

function showSlide(index) {
    slides[currentSlide].style.display = 'none';
    navLabels[currentSlide].classList.remove('active');

    slides[index].style.display = 'block';
    navLabels[index].classList.add('active');

    currentSlide = index;
}

function nextSlide() {
    showSlide((currentSlide + 1) % slides.length);
}

setInterval(nextSlide, 3000); // Change the interval (3000 milliseconds) to adjust the transition speed
// Seleciona os elementos
const loginModal = document.getElementById("loginModal");
const userIcon = document.getElementById("myuser");
const closeBtn = document.querySelector(".close-btn");

// Quando o ícone de usuário for clicado, exibe o modal de login
userIcon.onclick = function() {
    loginModal.style.display = "block";
}

// Quando o usuário clicar no "x", fecha o modal
closeBtn.onclick = function() {
    loginModal.style.display = "none";
}

// Quando o usuário clicar fora do modal, também fecha
window.onclick = function(event) {
    if (event.target == loginModal) {
        loginModal.style.display = "none";
    }
}
// Seleciona todos os links da navbar
const navbarLinks = document.querySelectorAll('.navbar a');

// Função para remover a classe 'active' de todos os links
function removeActiveClass() {
    navbarLinks.forEach(link => {
        link.classList.remove('active');
    });
}

// Adiciona um evento de clique a cada link
navbarLinks.forEach(link => {
    link.addEventListener('click', function() {
        removeActiveClass(); // Remove a classe 'active' de todos
        this.classList.add('active'); // Adiciona a classe 'active' ao link clicado
    });
});

















































// let search = document.querySelector('#serach-bar');
// let searchbox =document.querySelector('.search-box');

// search.onclick = () =>{
//     searchbox.classList.toggle('active');
// }
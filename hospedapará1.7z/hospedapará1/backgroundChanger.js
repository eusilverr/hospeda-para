document.addEventListener("DOMContentLoaded", function() {
    const mainBackground = document.querySelector('.main-background');
    const images = [
        "url('imgaes/amazonia 3.jpg')",
        "url('imgaes/amazonia 2.jpg')",
        "url('imgaes/amazonia.jpeg')",
        "url('imgaes/amazonia 4.jpg')"
    ];
    
    let currentIndex = 0;

    function changeBackground() {
        // Muda a imagem de fundo
        mainBackground.style.backgroundImage = images[currentIndex];
        // Atualiza o índice para a próxima imagem
        currentIndex = (currentIndex + 1) % images.length;
    }

    // Muda a imagem a cada 10 segundos (10000 milissegundos)
    setInterval(changeBackground, 3000);

    // Chama a função imediatamente para exibir a primeira imagem sem esperar os 10 segundos
    changeBackground();
});
